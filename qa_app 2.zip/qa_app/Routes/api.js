const express = require('express');
const router = express.Router();
const mysql = require('mysql');

// MySQL Create Connection
/*
If the following code throws the error "ER_NOT_SUPPORTED_AUTH_MODE" run this query in mysql workbench:

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '0000';

flush privileges;

*/
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Estrella5@",
    database: "q_a"
});

connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});


// Add question
router.post('/addQuestion', (request, response) => {

    connection.query(`Insert into question(title, fecha, body) values('${request.body.title}', '${request.body.date}', '${request.body.body}');`, function (err, result) {
        if (err) throw err;
        response.render("question", { dataTitle: request.body.Title, dataDate: request.body.Date, dataBody: request.body.Body });
    });

});

// Add response
router.post('/addResponse', (request, response) => {

    connection.query(`Insert into response(title, fecha, body) values('${request.body.title}', '${request.body.date}', '${request.body.body}');`, function (err, result) {
        if (err) throw err;
        response.render("response", { dataTitle: request.body.Title, dataDate: request.body.Date, dataBody: request.body.Body });
    });

});

// Get all questions
router.get('/allQuestions', (request, response) => {
    connection.query(`select * from question;`, function (err, result) {
        if (err) throw err;
        response.render("allQuestions", { question: result });
    });

});

module.exports = router;